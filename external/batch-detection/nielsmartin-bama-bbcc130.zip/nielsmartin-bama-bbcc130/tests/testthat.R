library(testthat)
library(bamalog)

test_check("bamalog")
